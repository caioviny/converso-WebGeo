# -*- coding: utf-8 -*-
"""
Plugin Converter - Versão com seleção por polígono integrada
"""
from qgis.PyQt.QtCore import QSettings, QTranslator, QCoreApplication, Qt, QVariant
from qgis.PyQt.QtGui import QIcon, QColor
from qgis.PyQt.QtWidgets import (QAction, QMessageBox, QFileDialog, QDialog,
                                 QVBoxLayout, QHBoxLayout, QPushButton, QLabel,
                                 QLineEdit, QProgressBar, QGroupBox)
from .seila_dialog import ConverterDialog
from qgis.core import (
    QgsProject,
    QgsVectorLayer,
    QgsField,
    QgsFeature,
    QgsWkbTypes,
    QgsFeatureRequest,
    QgsProcessing,
    QgsProcessingContext,
    QgsProcessingFeedback,
    QgsCoordinateReferenceSystem,
    QgsVectorFileWriter,
    QgsGeometry,
    QgsPointXY,
)
from qgis.gui import QgsMapTool, QgsRubberBand
from qgis.utils import iface as global_iface
import os.path
import processing

class CustomMapTool(QgsMapTool):
    def __init__(self, canvas):
        QgsMapTool.__init__(self, canvas)
        self.canvas = canvas
        self.canvasClicked = None
        self.canvasRightClicked = None

    def canvasReleaseEvent(self, event):
        if event.button() == Qt.LeftButton:
            if self.canvasClicked:
                point = self.toMapCoordinates(event.pos())
                self.canvasClicked(point)
        elif event.button() == Qt.RightButton:
            if self.canvasRightClicked:
                point = self.toMapCoordinates(event.pos())
                self.canvasRightClicked(point)

class Converter:
    """Plugin Conversão para GeoWEB - com seleção por polígono"""
    def __init__(self, iface):
        self.iface = iface if iface else global_iface
        self.plugin_dir = os.path.dirname(__file__)
        locale = QSettings().value('locale/userLocale')[0:2]
        locale_path = os.path.join(
            self.plugin_dir, 'i18n', f'Converter_{locale}.qm'
        )
        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)
            QCoreApplication.installTranslator(self.translator)
        self.actions = []
        self.menu = self.tr(u'&Conversão para GeoWEB')
        self.first_start = None
        self.selected_features = []
        self.map_tool = None
        self.diretorio_saida = None
        self.camada_quadra = None
        self.highlight_rubber_bands = []

        # Variáveis para desenho do polígono
        self.points_polygon = []
        self.rubber_band_polygon = None
        self.temp_rubber_band = None

    def tr(self, message):
        return QCoreApplication.translate('Converter', message)

    def add_action(
        self,
        icon_path,
        text,
        callback,
        enabled_flag=True,
        add_to_menu=True,
        add_to_toolbar=True,
        parent=None
    ):
        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)
        if add_to_toolbar:
            self.iface.addToolBarIcon(action)
        if add_to_menu:
            self.iface.addPluginToMenu(self.menu, action)
        self.actions.append(action)
        return action

    def initGui(self):
        icon_path = os.path.join(self.plugin_dir, 'icon.png')
        self.add_action(
            icon_path,
            text=self.tr(u'Conversão para GeoWEB'),
            callback=self.run,
            parent=self.iface.mainWindow()
        )
        self.first_start = True

    def unload(self):
        self.limpar_destaques()
        for action in self.actions:
            self.iface.removePluginMenu(self.menu, action)
            self.iface.removeToolBarIcon(action)
        if self.camada_quadra:
            self.camada_quadra.removeSelection()

    def run(self):
        if self.first_start:
            self.first_start = False
            self.dlg = ConverterDialog(parent=self.iface.mainWindow())
            self.dlg.Toolbtn.clicked.connect(self.escolher_pasta)
            self.dlg.btnSelecionar.clicked.connect(self.ativar_selecao)
            self.dlg.btnProcessar.clicked.connect(self.executar_conversao)

        # Reseta as seleções
        self.selected_features = []
        self.diretorio_saida = None
        self.dlg.lblPasta.clear()
        self.dlg.progressBar.setValue(0)
        self.dlg.lblInfo.setText("Nenhuma quadra selecionada")
        self.dlg.btnProcessar.setEnabled(False)
        self.limpar_destaques()

        self.dlg.setWindowModality(Qt.NonModal)
        self.dlg.show()

    def escolher_pasta(self):
        """Abre diálogo para escolher a pasta de destino"""
        diretorio = QFileDialog.getExistingDirectory(
            self.dlg,
            "Selecione o diretório para salvar as camadas",
            "",
            QFileDialog.ShowDirsOnly
        )
        if diretorio:
            self.diretorio_saida = diretorio
            self.dlg.lblPasta.setText(diretorio)
            self.atualizar_botao_processar()
            self.dlg.lblPasta.setText(f"{diretorio}\n")

    def atualizar_botao_processar(self):
        """Habilita o botão Processar apenas se pasta e quadras estiverem selecionadas"""
        if self.diretorio_saida and len(self.selected_features) > 0:
            self.dlg.btnProcessar.setEnabled(True)
        else:
            self.dlg.btnProcessar.setEnabled(False)

    def limpar_destaques(self):
        """Remove todos os destaques visuais das quadras"""
        for rubber_band in self.highlight_rubber_bands:
            rubber_band.reset()
        self.highlight_rubber_bands = []
        self.iface.mapCanvas().refresh()

    def destacar_quadras(self, features):
        """Destaca visualmente as quadras selecionadas em amarelo"""
        self.limpar_destaques()

        for feature in features:
            rubber_band = QgsRubberBand(self.iface.mapCanvas(), QgsWkbTypes.PolygonGeometry)
            rubber_band.setColor(QColor(255, 255, 0, 180))  # Amarelo vibrante
            rubber_band.setFillColor(QColor(255, 255, 0, 100))  # Amarelo semitransparente
            rubber_band.setWidth(4)
            rubber_band.setToGeometry(feature.geometry(), None)
            self.highlight_rubber_bands.append(rubber_band)

        self.iface.mapCanvas().refresh()

    def inicializar_rubber_bands(self):
        """Inicializa os rubber bands para desenho do polígono"""
        if self.rubber_band_polygon is None:
            self.rubber_band_polygon = QgsRubberBand(
                self.iface.mapCanvas(),
                QgsWkbTypes.PolygonGeometry
            )
            self.rubber_band_polygon.setColor(QColor(255, 0, 0, 100))
            self.rubber_band_polygon.setWidth(2)

        if self.temp_rubber_band is None:
            self.temp_rubber_band = QgsRubberBand(
                self.iface.mapCanvas(),
                QgsWkbTypes.LineGeometry
            )
            self.temp_rubber_band.setColor(QColor(255, 0, 0, 150))
            self.temp_rubber_band.setWidth(2)

    def resetar_desenho_poligono(self):
        """Reseta o desenho do polígono"""
        self.points_polygon = []
        if self.rubber_band_polygon:
            self.rubber_band_polygon.reset(QgsWkbTypes.PolygonGeometry)
        if self.temp_rubber_band:
            self.temp_rubber_band.reset(QgsWkbTypes.LineGeometry)

    def canvas_release_event(self, point):
        """Adiciona ponto ao polígono ao clicar com o botão esquerdo"""
        self.points_polygon.append(point)
        self.rubber_band_polygon.addPoint(point, True)
        self.rubber_band_polygon.show()

    def canvas_right_release_event(self, point):
        """Finaliza o polígono ao clicar com o botão direito"""
        if len(self.points_polygon) >= 3:
            polygon = QgsGeometry.fromPolygonXY([self.points_polygon])
            self.processar_poligono(polygon)
            self.resetar_desenho_poligono()
        else:
            QMessageBox.warning(self.dlg, "Aviso", "O polígono precisa de pelo menos 3 pontos.")

    def canvas_move_event(self, event):
        """Mostra linha temporária enquanto move o mouse"""
        if len(self.points_polygon) > 0:
            point = self.iface.mapCanvas().getCoordinateTransform().toMapCoordinates(
                event.pos().x(), event.pos().y()
            )
            self.temp_rubber_band.reset(QgsWkbTypes.LineGeometry)
            self.temp_rubber_band.addPoint(self.points_polygon[-1], False)
            self.temp_rubber_band.addPoint(point, True)
            self.temp_rubber_band.show()

    def canvas_key_press_event(self, event):
        """Cancela o desenho do polígono ao pressionar ESC"""
        if event.key() == Qt.Key_Escape:
            self.resetar_desenho_poligono()
            self.iface.mapCanvas().unsetMapTool(self.map_tool)
            QMessageBox.information(self.dlg, "Cancelado", "Seleção por polígono cancelada.")

    def ativar_selecao(self):
        """Ativa modo de desenho de polígono para selecionar múltiplas quadras"""
        if not self.diretorio_saida:
            QMessageBox.warning(self.dlg, "Aviso", "Por favor, escolha primeiro a pasta de destino.")
            return

        # Busca a camada Quadra
        self.camada_quadra = None
        for lyr in QgsProject.instance().mapLayers().values():
            if lyr.name().lower() == "quadra" and lyr.type() == QgsVectorLayer.VectorLayer:
                self.camada_quadra = lyr
                break
        if self.camada_quadra is None:
            QMessageBox.warning(self.dlg, "Aviso", "Camada 'Quadra' não encontrada no projeto.")
            return

        self.limpar_destaques()
        self.resetar_desenho_poligono()
        self.inicializar_rubber_bands()

        # Cria ferramenta de mapa customizada
        self.map_tool = CustomMapTool(self.iface.mapCanvas())
        self.map_tool.canvasClicked = self.canvas_release_event
        self.map_tool.canvasRightClicked = self.canvas_right_release_event
        self.iface.mapCanvas().setMapTool(self.map_tool)

        self.dlg.lblInfo.setText(
            "Desenhe um polígono no mapa:\n"
            "• Clique com botão esquerdo para adicionar pontos\n"
            "• Clique com botão direito para finalizar o polígono\n"
            "• ESC para cancelar"
        )

        QMessageBox.information(
            self.dlg,
            "Modo de Seleção Ativado",
            "Desenhe um polígono clicando no mapa.\n\n"
            "• Clique com botão esquerdo para adicionar pontos\n"
            "• Clique com botão direito para finalizar o polígono\n"
            "• Pressione ESC para cancelar\n\n"
            "Todas as quadras dentro do polígono serão selecionadas."
        )

    def processar_poligono(self, polygon):
        """Processa o polígono desenhado e seleciona as quadras"""
        if not self.camada_quadra:
            return

        self.iface.mapCanvas().unsetMapTool(self.map_tool)

        request = QgsFeatureRequest().setFilterRect(polygon.boundingBox())
        quadras_selecionadas = []

        for feature in self.camada_quadra.getFeatures(request):
            if polygon.intersects(feature.geometry()):
                quadras_selecionadas.append(feature)

        if len(quadras_selecionadas) == 0:
            QMessageBox.information(
                self.dlg,
                "Nenhuma Quadra",
                "Nenhuma quadra foi encontrada dentro do polígono desenhado."
            )
            self.dlg.lblInfo.setText("Nenhuma quadra selecionada")
            return

        self.selected_features = quadras_selecionadas
        self.destacar_quadras(quadras_selecionadas)

        ins_quadras = []
        for feat in self.selected_features:
            if 'ins_quadra' in [field.name() for field in feat.fields()]:
                ins_quadras.append(str(feat['ins_quadra']))
            else:
                ins_quadras.append(f"ID:{feat.id()}")

        self.dlg.lblInfo.setText(
            f"{len(self.selected_features)} quadra(s) selecionada(s):\n"
            f"({', '.join(ins_quadras)})"
        )

        self.atualizar_botao_processar()

        QMessageBox.information(
            self.dlg,
            "Seleção Concluída",
            f"{len(self.selected_features)} quadra(s) selecionada(s):\n{', '.join(ins_quadras)}"
        )

    def atualizar_progresso(self, valor, mensagem):
        """Atualiza a barra de progresso e a mensagem"""
        self.dlg.progressBar.setValue(valor)
        QCoreApplication.processEvents()

    def executar_conversao(self):
        """Executa a conversão completa das quadras selecionadas e exporta para arquivo"""
        if not self.selected_features:
            QMessageBox.warning(self.dlg, "Aviso", "Nenhuma quadra foi selecionada.")
            return
        if not self.diretorio_saida:
            QMessageBox.warning(self.dlg, "Aviso", "Diretório de saída não foi definido.")
            return
        if self.map_tool:
            self.iface.mapCanvas().unsetMapTool(self.map_tool)
        self.dlg.btnProcessar.setEnabled(False)
        self.dlg.btnSelecionar.setEnabled(False)
        camada_quadra = None
        for lyr in QgsProject.instance().mapLayers().values():
            if lyr.name().lower() == "quadra" and isinstance(lyr, QgsVectorLayer):
                camada_quadra = lyr
                break
        if not camada_quadra:
            QMessageBox.critical(self.dlg, "Erro", "Camada 'Quadra' não encontrada.")
            self.reabilitar_botoes()
            return
        ins_quadras = []
        for feat in self.selected_features:
            if 'ins_quadra' in [field.name() for field in feat.fields()]:
                ins_quadras.append(str(feat['ins_quadra']))
            else:
                ins_quadras.append(f"ID:{feat.id()}")
        context = QgsProcessingContext()
        feedback = QgsProcessingFeedback()
        try:
            self.atualizar_progresso(5, "Iniciando processamento...")
            camada_lote = None
            camada_slote = None
            camada_setor = None
            for lyr in QgsProject.instance().mapLayers().values():
                nome = lyr.name().lower()
                if "lote" in nome and "slote" not in nome:
                    camada_lote = lyr
                elif "slote" in nome:
                    camada_slote = lyr
                elif "setor" in nome:
                    camada_setor = lyr
            if not camada_lote or not camada_slote:
                QMessageBox.warning(self.dlg, "Aviso",
                    "Camadas 'Lote' e/ou 'Slote' não encontradas no projeto.")
                self.reabilitar_botoes()
                return
            self.atualizar_progresso(10, f"Processando {len(self.selected_features)} quadra(s)...")
            quadra_temp = QgsVectorLayer(
                f"{QgsWkbTypes.displayString(camada_quadra.wkbType())}?crs=EPSG:31984",
                "Quadras_Selecionadas",
                "memory"
            )
            prov = quadra_temp.dataProvider()
            prov.addAttributes(camada_quadra.fields())
            quadra_temp.updateFields()
            for selected_feature in self.selected_features:
                feat_temp = QgsFeature()
                feat_temp.setGeometry(selected_feature.geometry())
                feat_temp.setAttributes(selected_feature.attributes())
                prov.addFeature(feat_temp)

            quadra_temp.updateExtents()
            self.atualizar_progresso(15, "Extraindo Slotes...")
            slotes_extraidos = processing.run('native:extractbylocation', {
                'INPUT': camada_slote,
                'INTERSECT': quadra_temp,
                'PREDICATE': [0],
                'OUTPUT': 'memory:'
            }, context=context, feedback=feedback)['OUTPUT']
            self.atualizar_progresso(20, "Extraindo Lotes...")
            lotes_extraidos = processing.run('native:extractbylocation', {
                'INPUT': camada_lote,
                'INTERSECT': quadra_temp,
                'PREDICATE': [0],
                'OUTPUT': 'memory:'
            }, context=context, feedback=feedback)['OUTPUT']
            self.atualizar_progresso(25, "Processando Quadras...")
            quadras_processadas = processing.run('native:refactorfields', {
                'INPUT': quadra_temp,
                'FIELDS_MAPPING': [
                    {'expression': 'lpad("quadra",4,0)', 'length': 4, 'name': 'Quadra', 'precision': 0, 'type': 10},
                    {'expression': 'lpad(aggregate(layer:=\'Setor\', aggregate:=\'max\', expression:="setor", filter:=intersects($geometry, geometry(@parent))),2,0)',
                     'length': 2, 'name': 'Zona', 'precision': 0, 'type': 10}
                ],
                'OUTPUT': 'memory:'
            }, context=context, feedback=feedback)['OUTPUT']
            self.atualizar_progresso(30, "Filtrando Lotes com matrícula...")
            lotes_com_matricula = processing.run('native:extractbyexpression', {
                'INPUT': lotes_extraidos,
                'EXPRESSION': '"matricula" is not null',
                'OUTPUT': 'memory:'
            }, context=context, feedback=feedback)['OUTPUT']
            self.atualizar_progresso(35, "Filtrando Slotes com matrícula...")
            slotes_com_matricula = processing.run('native:extractbyexpression', {
                'INPUT': slotes_extraidos,
                'EXPRESSION': '"matricula" is not null',
                'OUTPUT': 'memory:'
            }, context=context, feedback=feedback)['OUTPUT']
            self.atualizar_progresso(40, "Convertendo Lotes para linhas...")
            lotes_linhas = processing.run('native:polygonstolines', {
                'INPUT': lotes_com_matricula,
                'OUTPUT': 'memory:'
            }, context=context, feedback=feedback)['OUTPUT']
            self.atualizar_progresso(45, "Convertendo Slotes para linhas...")
            slotes_linhas = processing.run('native:polygonstolines', {
                'INPUT': slotes_com_matricula,
                'OUTPUT': 'memory:'
            }, context=context, feedback=feedback)['OUTPUT']
            self.atualizar_progresso(50, "Criando centroides dos Lotes...")
            centroides_lotes = processing.run('native:centroids', {
                'INPUT': lotes_com_matricula,
                'ALL_PARTS': False,
                'OUTPUT': 'memory:'
            }, context=context, feedback=feedback)['OUTPUT']
            self.atualizar_progresso(55, "Criando centroides dos Slotes...")
            centroides_slotes = processing.run('native:centroids', {
                'INPUT': slotes_com_matricula,
                'ALL_PARTS': False,
                'OUTPUT': 'memory:'
            }, context=context, feedback=feedback)['OUTPUT']
            self.atualizar_progresso(60, "Adicionando Zona aos Lotes...")
            lotes_linhas_zona = processing.run('native:refactorfields', {
                'INPUT': lotes_linhas,
                'FIELDS_MAPPING': [
                    {'expression': 'lpad(aggregate(layer:=\'Setor\', aggregate:=\'max\', expression:="setor", filter:=intersects($geometry, geometry(@parent))),2,0)',
                     'length': 2, 'name': 'Zona', 'precision': 0, 'type': 10}
                ],
                'OUTPUT': 'memory:'
            }, context=context, feedback=feedback)['OUTPUT']
            self.atualizar_progresso(65, "Adicionando Zona aos Slotes...")
            slotes_linhas_zona = processing.run('native:refactorfields', {
                'INPUT': slotes_linhas,
                'FIELDS_MAPPING': [
                    {'expression': 'lpad(aggregate(layer:=\'Setor\', aggregate:=\'max\', expression:="setor", filter:=intersects($geometry, geometry(@parent))),2,0)',
                     'length': 2, 'name': 'Zona', 'precision': 0, 'type': 10}
                ],
                'OUTPUT': 'memory:'
            }, context=context, feedback=feedback)['OUTPUT']
            self.atualizar_progresso(70, "Mesclando linhas...")
            linhas_mescladas = processing.run('native:mergevectorlayers', {
                'LAYERS': [slotes_linhas_zona, lotes_linhas_zona],
                'CRS': QgsCoordinateReferenceSystem('EPSG:31984'),
                'OUTPUT': 'memory:'
            }, context=context, feedback=feedback)['OUTPUT']
            self.atualizar_progresso(75, "Processando centroides dos Lotes...")
            centroides_lotes_valor = processing.run('native:refactorfields', {
                'INPUT': centroides_lotes,
                'FIELDS_MAPPING': [
                    {'expression': '"matricula"', 'length': 12, 'name': 'Valor', 'precision': 0, 'type': 10}
                ],
                'OUTPUT': 'memory:'
            }, context=context, feedback=feedback)['OUTPUT']
            self.atualizar_progresso(78, "Processando centroides dos Slotes...")
            centroides_slotes_valor = processing.run('native:refactorfields', {
                'INPUT': centroides_slotes,
                'FIELDS_MAPPING': [
                    {'expression': '"matricula"', 'length': 12, 'name': 'Valor', 'precision': 0, 'type': 10}
                ],
                'OUTPUT': 'memory:'
            }, context=context, feedback=feedback)['OUTPUT']
            self.atualizar_progresso(80, "Mesclando centroides...")
            centroides_mesclados = processing.run('native:mergevectorlayers', {
                'LAYERS': [centroides_slotes_valor, centroides_lotes_valor],
                'CRS': QgsCoordinateReferenceSystem('EPSG:31984'),
                'OUTPUT': 'memory:'
            }, context=context, feedback=feedback)['OUTPUT']
            self.atualizar_progresso(83, "Finalizando camada de Lotes...")
            lotes_final = processing.run('native:refactorfields', {
                'INPUT': linhas_mescladas,
                'FIELDS_MAPPING': [
                    {'expression': '"Zona"', 'length': 2, 'name': 'Zona', 'precision': 0, 'type': 10}
                ],
                'OUTPUT': 'memory:'
            }, context=context, feedback=feedback)['OUTPUT']
            self.atualizar_progresso(85, "Finalizando camada Simb_Zn...")
            simb_zn_final = processing.run('native:refactorfields', {
                'INPUT': centroides_mesclados,
                'FIELDS_MAPPING': [
                    {'expression': '"Valor"', 'length': 12, 'name': 'Valor', 'precision': 0, 'type': 10}
                ],
                'OUTPUT': 'memory:'
            }, context=context, feedback=feedback)['OUTPUT']
            camadas_para_salvar = [
                (simb_zn_final, "Simb_Zn"),
                (lotes_final, "Lotes"),
                (quadras_processadas, "Quadras")
            ]

            progresso_salvar = 85
            incremento = 10 / len(camadas_para_salvar)

            for camada, nome_base in camadas_para_salvar:
                self.atualizar_progresso(int(progresso_salvar), f"Salvando {nome_base}...")
                caminho_saida = os.path.join(self.diretorio_saida, f"{nome_base}.shp")

                QgsVectorFileWriter.writeAsVectorFormat(
                    camada,
                    caminho_saida,
                    "UTF-8",
                    QgsCoordinateReferenceSystem("EPSG:31984"),
                    "ESRI Shapefile"
                )
                progresso_salvar += incremento
            self.atualizar_progresso(95, "Carregando camadas no QGIS...")

            root = QgsProject.instance().layerTreeRoot()
            grupo_geoweb = root.addGroup("Geoweb")

            for camada, nome_base in camadas_para_salvar:
                caminho_saida = os.path.join(self.diretorio_saida, f"{nome_base}.shp")
                nova_camada = QgsVectorLayer(caminho_saida, nome_base, "ogr")

                if nova_camada.isValid():
                    QgsProject.instance().addMapLayer(nova_camada, False)
                    grupo_geoweb.addLayer(nova_camada)
                else:
                    QMessageBox.warning(self.dlg, "Aviso", f"Não foi possível carregar a camada: {nome_base}")
            self.atualizar_progresso(100, "Conversão concluída com sucesso!")

            quadras_texto = ', '.join(ins_quadras)
            QMessageBox.information(self.dlg, "Sucesso",
                f"Conversão concluída com sucesso!\n\n"
                f"Quadras selecionadas: ({quadras_texto})\n\n"
                f"Camadas salvas em: {self.diretorio_saida}\n"
                f"Camadas criadas:\n"
                f"- Quadras ({len(self.selected_features)} quadra(s))\n"
                f"- Lotes\n"
                f"- Simb_Zn\n\n"
                f"As camadas foram carregadas no grupo 'Geoweb'.")

            self.selected_features = []
            self.reabilitar_botoes()
        except Exception as e:
            QMessageBox.critical(self.dlg, "Erro", f"Erro durante o processamento:\n{str(e)}")
            self.atualizar_progresso(0, "Erro no processamento.")
            self.reabilitar_botoes()

    def reabilitar_botoes(self):
        """Reabilita os botões após o processamento"""
        self.dlg.btnSelecionar.setEnabled(True)
        self.atualizar_botao_processar()
